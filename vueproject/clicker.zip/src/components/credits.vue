<template>
    <div class="credits show" id="credits">
            <h2>Thanks to this awesome artists
            </h2>
            <a href="https://edermunizz.itch.io/free-pixel-art-forest" target="_blank">background image: by Eder Muniz</a>
            <a href="https://kyrise.itch.io/kyrises-free-16x16-rpg-icon-pack" target="_blank">pixel art icons: by Kyrise</a>
            <a href="https://clembod.itch.io/warrior-free-animation-set" target="_blank">character: by Clembod</a>
            <a href="https://royal-naym.itch.io/dark-nights-wallpaper-pack" target="_blank">other background images: by Royal Naym</a>
            <p>Code, design and rest is by Lukáš Kníže</p>
        </div>
</template>