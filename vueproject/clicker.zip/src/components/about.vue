<template>
  <div class="about show" id="about">
    <h2>cool game I gues UwU</h2>
    <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" target="_blank">for more</a>
  </div>
</template>