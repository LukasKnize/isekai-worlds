<template>
  <!-- Jestli se k tomuhle někdy dostanu... -->

  <div class="lore show" id="lore">
    <h2>isekai worlds lore</h2>
    <p>
      lore, more like Lorem ipsum dolor sit amet consectetur adipisicing elit.
      Debitis nulla totam doloremque, excepturi delectus magni reiciendis qui
      ab, quam, consequuntur harum architecto ipsum recusandae aspernatur
      voluptatum atque iure provident pariatur.
    </p>
  </div>
</template>