<template>
<!-- Tuto část budu ještě dodělávat-->
    <div class="quests show" id="quests">
            <div class="questItem">
                <p>Click 300 times</p>
                <div class="progressBar">
                    <div class="progressBarFiller"></div>
                </div>
            </div>
            <div class="questItem">
                <p>Click 300 times</p>
                <div class="progressBar">
                    <div class="progressBarFiller"></div>
                </div>
            </div>
            <div class="questItem">
                <p>Click 300 times</p>
                <div class="progressBar">
                    <div class="progressBarFiller"></div>
                </div>
            </div>
        </div>
</template>