function mainMenu() {
    document.getElementById("mainMenu").classList.toggle("show");
    if(document.getElementById("credits").classList.contains("show")){
        document.getElementById("credits").classList.toggle("show");
    }

    if(document.getElementById("about").classList.contains("show")){
        document.getElementById("about").classList.toggle("show");
    }

    if(document.getElementById("shop").classList.contains("show")){
        document.getElementById("shop").classList.toggle("show");
    }    

    if(document.getElementById("quests").classList.contains("show")){
        document.getElementById("quests").classList.toggle("show");
    }
    
    if(document.getElementById("actions").classList.contains("show")){
        document.getElementById("actions").classList.toggle("show");
    }

    if(document.getElementById("bossFight").classList.contains("show")){
        document.getElementById("bossFight").classList.toggle("show");
    }

    if(document.getElementById("stats").classList.contains("show")){
        document.getElementById("stats").classList.toggle("show");
    }

    if(document.getElementById("lore").classList.contains("show")){
        document.getElementById("lore").classList.toggle("show");
    }
}

function shop() {
    document.getElementById("shop").classList.toggle("show");

    if(document.getElementById("credits").classList.contains("show")){
        document.getElementById("credits").classList.toggle("show");
    }

    if(document.getElementById("about").classList.contains("show")){
        document.getElementById("about").classList.toggle("show");
    }

    if(document.getElementById("mainMenu").classList.contains("show")){
        document.getElementById("mainMenu").classList.toggle("show");
    }    

    if(document.getElementById("quests").classList.contains("show")){
        document.getElementById("quests").classList.toggle("show");
    }
    
    if(document.getElementById("actions").classList.contains("show")){
        document.getElementById("actions").classList.toggle("show");
    }

    if(document.getElementById("bossFight").classList.contains("show")){
        document.getElementById("bossFight").classList.toggle("show");
    }

    if(document.getElementById("stats").classList.contains("show")){
        document.getElementById("stats").classList.toggle("show");
    }

    if(document.getElementById("lore").classList.contains("show")){
        document.getElementById("lore").classList.toggle("show");
    }
}

function quests() {
    document.getElementById("quests").classList.toggle("show");

    if(document.getElementById("credits").classList.contains("show")){
        document.getElementById("credits").classList.toggle("show");
    }

    if(document.getElementById("about").classList.contains("show")){
        document.getElementById("about").classList.toggle("show");
    }

    if(document.getElementById("mainMenu").classList.contains("show")){
        document.getElementById("mainMenu").classList.toggle("show");
    }    

    if(document.getElementById("shop").classList.contains("show")){
        document.getElementById("shop").classList.toggle("show");
    }
    
    if(document.getElementById("actions").classList.contains("show")){
        document.getElementById("actions").classList.toggle("show");
    }

    if(document.getElementById("bossFight").classList.contains("show")){
        document.getElementById("bossFight").classList.toggle("show");
    }

    if(document.getElementById("stats").classList.contains("show")){
        document.getElementById("stats").classList.toggle("show");
    }

    if(document.getElementById("lore").classList.contains("show")){
        document.getElementById("lore").classList.toggle("show");
    }
}

function actions() {
    document.getElementById("actions").classList.toggle("show");

    if(document.getElementById("credits").classList.contains("show")){
        document.getElementById("credits").classList.toggle("show");
    }

    if(document.getElementById("about").classList.contains("show")){
        document.getElementById("about").classList.toggle("show");
    }

    if(document.getElementById("mainMenu").classList.contains("show")){
        document.getElementById("mainMenu").classList.toggle("show");
    }    

    if(document.getElementById("shop").classList.contains("show")){
        document.getElementById("shop").classList.toggle("show");
    }
    
    if(document.getElementById("quests").classList.contains("show")){
        document.getElementById("quests").classList.toggle("show");
    }

    if(document.getElementById("bossFight").classList.contains("show")){
        document.getElementById("bossFight").classList.toggle("show");
    }

    if(document.getElementById("stats").classList.contains("show")){
        document.getElementById("stats").classList.toggle("show");
    }

    if(document.getElementById("lore").classList.contains("show")){
        document.getElementById("lore").classList.toggle("show");
    }
}

function credits() {
    document.getElementById("credits").classList.toggle("show");

    if(document.getElementById("actions").classList.contains("show")){
        document.getElementById("actions").classList.toggle("show");
    }

    if(document.getElementById("about").classList.contains("show")){
        document.getElementById("about").classList.toggle("show");
    }

    if(document.getElementById("mainMenu").classList.contains("show")){
        document.getElementById("mainMenu").classList.toggle("show");
    }    

    if(document.getElementById("shop").classList.contains("show")){
        document.getElementById("shop").classList.toggle("show");
    }
    
    if(document.getElementById("quests").classList.contains("show")){
        document.getElementById("quests").classList.toggle("show");
    }

    if(document.getElementById("bossFight").classList.contains("show")){
        document.getElementById("bossFight").classList.toggle("show");
    }

    if(document.getElementById("stats").classList.contains("show")){
        document.getElementById("stats").classList.toggle("show");
    }

    if(document.getElementById("lore").classList.contains("show")){
        document.getElementById("lore").classList.toggle("show");
    }
}

function about() {
    document.getElementById("about").classList.toggle("show");

    if(document.getElementById("credits").classList.contains("show")){
        document.getElementById("credits").classList.toggle("show");
    }

    if(document.getElementById("actions").classList.contains("show")){
        document.getElementById("actions").classList.toggle("show");
    }

    if(document.getElementById("mainMenu").classList.contains("show")){
        document.getElementById("mainMenu").classList.toggle("show");
    }    

    if(document.getElementById("shop").classList.contains("show")){
        document.getElementById("shop").classList.toggle("show");
    }
    
    if(document.getElementById("quests").classList.contains("show")){
        document.getElementById("quests").classList.toggle("show");
    }

    if(document.getElementById("bossFight").classList.contains("show")){
        document.getElementById("bossFight").classList.toggle("show");
    }

    if(document.getElementById("stats").classList.contains("show")){
        document.getElementById("stats").classList.toggle("show");
    }

    if(document.getElementById("lore").classList.contains("show")){
        document.getElementById("lore").classList.toggle("show");
    }
}

function bossFight(){
    document.getElementById("bossFight").classList.toggle("show");

    if(document.getElementById("credits").classList.contains("show")){
        document.getElementById("credits").classList.toggle("show");
    }

    if(document.getElementById("actions").classList.contains("show")){
        document.getElementById("actions").classList.toggle("show");
    }

    if(document.getElementById("mainMenu").classList.contains("show")){
        document.getElementById("mainMenu").classList.toggle("show");
    }    

    if(document.getElementById("shop").classList.contains("show")){
        document.getElementById("shop").classList.toggle("show");
    }
    
    if(document.getElementById("quests").classList.contains("show")){
        document.getElementById("quests").classList.toggle("show");
    }

    if(document.getElementById("about").classList.contains("show")){
        document.getElementById("about").classList.toggle("show");
    }

    if(document.getElementById("stats").classList.contains("show")){
        document.getElementById("stats").classList.toggle("show");
    }

    if(document.getElementById("lore").classList.contains("show")){
        document.getElementById("lore").classList.toggle("show");
    }
}

function stats(){
    document.getElementById("stats").classList.toggle("show");

    if(document.getElementById("credits").classList.contains("show")){
        document.getElementById("credits").classList.toggle("show");
    }

    if(document.getElementById("actions").classList.contains("show")){
        document.getElementById("actions").classList.toggle("show");
    }

    if(document.getElementById("mainMenu").classList.contains("show")){
        document.getElementById("mainMenu").classList.toggle("show");
    }    

    if(document.getElementById("shop").classList.contains("show")){
        document.getElementById("shop").classList.toggle("show");
    }
    
    if(document.getElementById("quests").classList.contains("show")){
        document.getElementById("quests").classList.toggle("show");
    }

    if(document.getElementById("about").classList.contains("show")){
        document.getElementById("about").classList.toggle("show");
    }

    if(document.getElementById("bossFight").classList.contains("show")){
        document.getElementById("bossFight").classList.toggle("show");
    }

    if(document.getElementById("lore").classList.contains("show")){
        document.getElementById("lore").classList.toggle("show");
    }
}

function lore(){
    document.getElementById("lore").classList.toggle("show");

    if(document.getElementById("credits").classList.contains("show")){
        document.getElementById("credits").classList.toggle("show");
    }

    if(document.getElementById("actions").classList.contains("show")){
        document.getElementById("actions").classList.toggle("show");
    }

    if(document.getElementById("mainMenu").classList.contains("show")){
        document.getElementById("mainMenu").classList.toggle("show");
    }    

    if(document.getElementById("shop").classList.contains("show")){
        document.getElementById("shop").classList.toggle("show");
    }
    
    if(document.getElementById("quests").classList.contains("show")){
        document.getElementById("quests").classList.toggle("show");
    }

    if(document.getElementById("about").classList.contains("show")){
        document.getElementById("about").classList.toggle("show");
    }

    if(document.getElementById("bossFight").classList.contains("show")){
        document.getElementById("bossFight").classList.toggle("show");
    }

    if(document.getElementById("stats").classList.contains("show")){
        document.getElementById("stats").classList.toggle("show");
    }
}


window.addEventListener("load", () =>{
    console.log("%cWhat are you doing there? and be honest!", "color:blue");
    console.log("\n");
});

let money = 0;
let attacking = false;
let attackTimeOut = setTimeout(() => {document.getElementById("character").src = "./assets/idleGif.gif";
attacking = false}, 2000);

function clicked() {
    money++;
    document.getElementById("money").textContent = money;
    if(attacking != true){
        document.getElementById("character").src = "./assets/attackGif.gif";
        attacking = true;
        window.clearTimeout(attackTimeOut);
        attackTimeOut = setTimeout(() => {document.getElementById("character").src = "./assets/idleGif.gif";
        attacking = false}, 2000);
    }else{
        window.clearTimeout(attackTimeOut);
        attackTimeOut = setTimeout(() => {document.getElementById("character").src = "./assets/idleGif.gif";
        attacking = false}, 2000);
    }

}

